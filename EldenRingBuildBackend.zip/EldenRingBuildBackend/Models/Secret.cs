﻿using Microsoft.VisualBasic;

namespace EldenRingBuildBackend.Models
{
    public class Secret
    {
        public static string information = "Data Source=eldenring.database.windows.net;Initial Catalog=EldenRingDB; User Id=ERProjDev; Password=dejcsirjvmsie246&";
    }
}

